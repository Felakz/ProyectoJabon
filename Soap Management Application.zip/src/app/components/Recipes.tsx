import { BookOpen, Droplet, Sparkles } from 'lucide-react';

interface Recipe {
  id: string;
  name: string;
  description: string;
  targetWeight: number;
  ingredients: Array<{
    ingredientId: string;
    percentage: number;
  }>;
  overfattingPercentage: number;
  waterDiscountPercentage: number;
}

interface Ingredient {
  id: string;
  name: string;
}

interface RecipesProps {
  recipes: Recipe[];
  ingredients: Ingredient[];
}

export function Recipes({ recipes, ingredients }: RecipesProps) {
  const getIngredientName = (id: string) => {
    const ingredient = ingredients.find(i => i.id === id);
    return ingredient ? ingredient.name : 'Desconocido';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <BookOpen className="w-8 h-8 text-emerald-500" />
        <h2 className="text-2xl font-bold">Biblioteca de Recetas</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {recipes.map(recipe => (
          <div key={recipe.id} className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow">
            <div className="bg-gradient-to-r from-emerald-500 to-blue-500 p-4 text-white">
              <h3 className="font-bold text-lg">{recipe.name}</h3>
              <p className="text-sm text-emerald-50">{recipe.description}</p>
            </div>

            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  <div>
                    <p className="text-xs text-gray-500">Sobreengrasado</p>
                    <p className="font-semibold">{recipe.overfattingPercentage}%</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Droplet className="w-4 h-4 text-blue-600" />
                  <div>
                    <p className="text-xs text-gray-500">Desc. Agua</p>
                    <p className="font-semibold">{recipe.waterDiscountPercentage}%</p>
                  </div>
                </div>
              </div>

              <div>
                <p className="text-sm font-medium mb-2">Composición:</p>
                <div className="space-y-2">
                  {recipe.ingredients.map((ing, idx) => (
                    <div key={idx} className="relative">
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm text-gray-700">
                          {getIngredientName(ing.ingredientId)}
                        </span>
                        <span className="text-sm font-semibold">{ing.percentage}%</span>
                      </div>
                      <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-emerald-400 to-emerald-500"
                          style={{ width: `${ing.percentage}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t">
                <p className="text-xs text-gray-500">
                  Peso por defecto: <span className="font-medium">{recipe.targetWeight}g</span>
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {recipes.length === 0 && (
        <div className="bg-gradient-to-r from-emerald-50 to-blue-50 rounded-xl p-12 text-center border border-emerald-200">
          <BookOpen className="w-16 h-16 text-emerald-300 mx-auto mb-4" />
          <p className="text-gray-600">No hay recetas disponibles</p>
        </div>
      )}
    </div>
  );
}
