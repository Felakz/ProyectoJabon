import { useState } from 'react';
import { Calculator as CalcIcon, AlertCircle, CheckCircle, Droplet, Beaker } from 'lucide-react';

interface Recipe {
  id: string;
  name: string;
  description: string;
  targetWeight: number;
  ingredients: Array<{
    ingredientId: string;
    percentage: number;
  }>;
  overfattingPercentage: number;
  waterDiscountPercentage: number;
}

interface CalculatorProps {
  recipes: Recipe[];
  onCalculate: (recipeId: string, targetWeight: number) => Promise<any>;
}

export function Calculator({ recipes, onCalculate }: CalculatorProps) {
  const [selectedRecipeId, setSelectedRecipeId] = useState<string>('');
  const [targetWeight, setTargetWeight] = useState<string>('1000');
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const handleCalculate = async () => {
    if (!selectedRecipeId || !targetWeight) return;

    setLoading(true);
    try {
      const calculation = await onCalculate(selectedRecipeId, parseFloat(targetWeight));
      setResult(calculation);
    } catch (error) {
      console.error('Error calculating:', error);
    } finally {
      setLoading(false);
    }
  };

  const selectedRecipe = recipes.find(r => r.id === selectedRecipeId);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <CalcIcon className="w-8 h-8 text-emerald-500" />
        <h2 className="text-2xl font-bold">Calculadora de Recetas</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-md p-6 space-y-4">
          <h3 className="font-semibold">Configuración del Batch</h3>

          <div>
            <label className="block text-sm font-medium mb-2">Selecciona una Receta</label>
            <select
              value={selectedRecipeId}
              onChange={(e) => setSelectedRecipeId(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
            >
              <option value="">-- Seleccionar --</option>
              {recipes.map(recipe => (
                <option key={recipe.id} value={recipe.id}>
                  {recipe.name}
                </option>
              ))}
            </select>
          </div>

          {selectedRecipe && (
            <div className="bg-emerald-50 p-4 rounded-lg border border-emerald-200">
              <p className="font-medium text-sm mb-1">{selectedRecipe.name}</p>
              <p className="text-sm text-gray-600 mb-2">{selectedRecipe.description}</p>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <span className="text-gray-500">Sobreengrasado:</span>
                  <span className="ml-1 font-medium">{selectedRecipe.overfattingPercentage}%</span>
                </div>
                <div>
                  <span className="text-gray-500">Descuento agua:</span>
                  <span className="ml-1 font-medium">{selectedRecipe.waterDiscountPercentage}%</span>
                </div>
              </div>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium mb-2">
              Peso Objetivo del Batch (gramos)
            </label>
            <input
              type="number"
              value={targetWeight}
              onChange={(e) => setTargetWeight(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
              placeholder="1000"
              min="100"
              step="50"
            />
          </div>

          <button
            onClick={handleCalculate}
            disabled={!selectedRecipeId || !targetWeight || loading}
            className="w-full bg-emerald-500 hover:bg-emerald-600 disabled:bg-gray-300 text-white py-3 rounded-lg font-medium transition-colors flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                Calculando...
              </>
            ) : (
              <>
                <CalcIcon className="w-4 h-4" />
                Calcular Batch
              </>
            )}
          </button>
        </div>

        {result && (
          <div className="bg-white rounded-xl shadow-md p-6 space-y-4">
            <h3 className="font-semibold">Resultados del Cálculo</h3>

            <div className="space-y-2">
              {result.alerts.map((alert: string, index: number) => (
                <div
                  key={index}
                  className={`flex items-start gap-2 p-3 rounded-lg ${
                    result.canMakeBatch
                      ? 'bg-emerald-50 text-emerald-700'
                      : 'bg-amber-50 text-amber-700'
                  }`}
                >
                  {result.canMakeBatch ? (
                    <CheckCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                  )}
                  <span className="text-sm">{alert}</span>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <div className="flex items-center gap-2 mb-1">
                  <Droplet className="w-4 h-4 text-blue-600" />
                  <span className="text-sm font-medium text-blue-900">Agua</span>
                </div>
                <p className="text-2xl font-bold text-blue-600">
                  {result.waterGrams}g
                </p>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                <div className="flex items-center gap-2 mb-1">
                  <Beaker className="w-4 h-4 text-purple-600" />
                  <span className="text-sm font-medium text-purple-900">Sosa (NaOH)</span>
                </div>
                <p className="text-2xl font-bold text-purple-600">
                  {result.lyeGrams}g
                </p>
              </div>
            </div>

            <div>
              <h4 className="font-medium text-sm mb-2">Aceites Requeridos:</h4>
              <div className="space-y-2">
                {result.oils.map((oil: any) => (
                  <div
                    key={oil.ingredientId}
                    className="flex justify-between items-center p-2 bg-gray-50 rounded"
                  >
                    <span className="text-sm">{oil.name}</span>
                    <div className="text-right">
                      <span className="font-medium">{oil.gramsNeeded}g</span>
                      <span className="text-xs text-gray-500 ml-2">
                        (${oil.cost.toFixed(2)})
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t">
              <div className="flex justify-between items-center">
                <span className="font-semibold">Costo Total del Batch:</span>
                <span className="text-2xl font-bold text-emerald-600">
                  ${result.totalCost.toFixed(2)}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>

      {!result && (
        <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-8 text-center border border-blue-200">
          <CalcIcon className="w-12 h-12 text-blue-400 mx-auto mb-4" />
          <p className="text-gray-600">
            Selecciona una receta y el peso objetivo para calcular tu batch
          </p>
        </div>
      )}
    </div>
  );
}
