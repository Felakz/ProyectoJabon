import { useState, useEffect } from 'react';
import { LayoutDashboard, Package, Calculator as CalcIcon, BookOpen, Sparkles } from 'lucide-react';
import { Dashboard } from './components/Dashboard';
import { Inventory } from './components/Inventory';
import { Calculator } from './components/Calculator';
import { Recipes } from './components/Recipes';
import { api, type Ingredient, type Recipe } from './services/api';

type Tab = 'dashboard' | 'inventory' | 'calculator' | 'recipes';

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [ingredientsData, recipesData] = await Promise.all([
        api.fetchIngredients(),
        api.fetchRecipes(),
      ]);
      setIngredients(ingredientsData);
      setRecipes(recipesData);
    } catch (err) {
      setError('Error al cargar los datos. Asegúrate de que el servidor API esté ejecutándose en http://localhost:3000');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddIngredient = async (ingredient: Omit<Ingredient, 'id' | 'costPerGram'>) => {
    try {
      const newIngredient = await api.createIngredient(ingredient);
      setIngredients([...ingredients, newIngredient]);
    } catch (err) {
      console.error('Error adding ingredient:', err);
      alert('Error al agregar el ingrediente');
    }
  };

  const handleUpdateIngredient = async (id: string, ingredient: Partial<Ingredient>) => {
    try {
      const updated = await api.updateIngredient(id, ingredient);
      setIngredients(ingredients.map(i => i.id === id ? updated : i));
    } catch (err) {
      console.error('Error updating ingredient:', err);
      alert('Error al actualizar el ingrediente');
    }
  };

  const handleDeleteIngredient = async (id: string) => {
    if (!confirm('¿Estás seguro de eliminar este ingrediente?')) return;

    try {
      await api.deleteIngredient(id);
      setIngredients(ingredients.filter(i => i.id !== id));
    } catch (err) {
      console.error('Error deleting ingredient:', err);
      alert('Error al eliminar el ingrediente');
    }
  };

  const handleCalculate = async (recipeId: string, targetWeight: number) => {
    return await api.calculateBatch(recipeId, targetWeight);
  };

  const tabs = [
    { id: 'dashboard' as Tab, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'inventory' as Tab, label: 'Inventario', icon: Package },
    { id: 'calculator' as Tab, label: 'Calculadora', icon: CalcIcon },
    { id: 'recipes' as Tab, label: 'Recetas', icon: BookOpen },
  ];

  if (loading) {
    return (
      <div className="size-full flex items-center justify-center bg-gradient-to-br from-emerald-50 to-blue-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-emerald-500 border-t-transparent mx-auto mb-4" />
          <p className="text-gray-600">Cargando aplicación...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="size-full flex items-center justify-center bg-gradient-to-br from-red-50 to-orange-50 p-4">
        <div className="bg-white rounded-xl shadow-lg p-8 max-w-md text-center">
          <div className="text-red-500 mb-4">⚠️</div>
          <h2 className="font-bold text-xl mb-2">Error de Conexión</h2>
          <p className="text-gray-600 mb-4">{error}</p>
          <button
            onClick={loadData}
            className="bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-2 rounded-lg transition-colors"
          >
            Reintentar
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="size-full bg-gradient-to-br from-emerald-50 to-blue-50 overflow-hidden flex flex-col">
      <header className="bg-white shadow-md border-b border-gray-200">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-r from-emerald-500 to-blue-500 p-2 rounded-lg">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-xl">Gestión de Jabones Artesanales</h1>
                <p className="text-sm text-gray-500">Sistema profesional de formulación y costeo</p>
              </div>
            </div>
            <div className="hidden md:flex items-center gap-2 text-sm text-gray-600">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
              <span>Conectado al servidor</span>
            </div>
          </div>
        </div>

        <nav className="container mx-auto px-4">
          <div className="flex gap-1 border-b border-gray-200">
            {tabs.map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-6 py-3 font-medium transition-colors relative ${
                    isActive
                      ? 'text-emerald-600'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                  {isActive && (
                    <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-emerald-500" />
                  )}
                </button>
              );
            })}
          </div>
        </nav>
      </header>

      <main className="flex-1 overflow-auto">
        <div className="container mx-auto px-4 py-6">
          {activeTab === 'dashboard' && (
            <Dashboard ingredients={ingredients} recipes={recipes} />
          )}
          {activeTab === 'inventory' && (
            <Inventory
              ingredients={ingredients}
              onAdd={handleAddIngredient}
              onUpdate={handleUpdateIngredient}
              onDelete={handleDeleteIngredient}
            />
          )}
          {activeTab === 'calculator' && (
            <Calculator recipes={recipes} onCalculate={handleCalculate} />
          )}
          {activeTab === 'recipes' && (
            <Recipes recipes={recipes} ingredients={ingredients} />
          )}
        </div>
      </main>

      <footer className="bg-white border-t border-gray-200 py-4">
        <div className="container mx-auto px-4 text-center text-sm text-gray-500">
          <p>🧼 Sistema de Gestión de Jabones Artesanales v1.0</p>
        </div>
      </footer>
    </div>
  );
}
