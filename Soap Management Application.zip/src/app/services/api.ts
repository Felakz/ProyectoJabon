const API_BASE_URL = 'http://localhost:3000/api';

export interface Ingredient {
  id: string;
  name: string;
  currentStock: number;
  totalCost: number;
  costPerGram: number;
  sapValue: number;
}

export interface Recipe {
  id: string;
  name: string;
  description: string;
  targetWeight: number;
  ingredients: Array<{
    ingredientId: string;
    percentage: number;
  }>;
  overfattingPercentage: number;
  waterDiscountPercentage: number;
}

class ApiService {
  async fetchIngredients(): Promise<Ingredient[]> {
    const response = await fetch(`${API_BASE_URL}/inventory`);
    const data = await response.json();
    return data.data;
  }

  async createIngredient(ingredient: Omit<Ingredient, 'id' | 'costPerGram'>): Promise<Ingredient> {
    const response = await fetch(`${API_BASE_URL}/inventory`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(ingredient),
    });
    const data = await response.json();
    return data.data;
  }

  async updateIngredient(id: string, ingredient: Partial<Ingredient>): Promise<Ingredient> {
    const response = await fetch(`${API_BASE_URL}/inventory/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(ingredient),
    });
    const data = await response.json();
    return data.data;
  }

  async deleteIngredient(id: string): Promise<void> {
    await fetch(`${API_BASE_URL}/inventory/${id}`, {
      method: 'DELETE',
    });
  }

  async fetchRecipes(): Promise<Recipe[]> {
    const response = await fetch(`${API_BASE_URL}/calculator/recipes`);
    const data = await response.json();
    return data.data;
  }

  async calculateBatch(recipeId: string, targetWeight: number): Promise<any> {
    const response = await fetch(`${API_BASE_URL}/calculator/calculate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ recipeId, targetWeight }),
    });
    const data = await response.json();
    return data.calculation;
  }
}

export const api = new ApiService();
