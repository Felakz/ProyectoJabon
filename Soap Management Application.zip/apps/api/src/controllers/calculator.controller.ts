/**
 * @fileoverview Controlador para cálculos de formulación de jabones
 * @module controllers/calculator
 */

import { Request, Response } from 'express';
import type {
  Recipe,
  SoapCalculation,
  CalculationRequest,
  CalculationResponse,
} from '../../../../packages/shared/src/types';
import {
  calculateGramsFromWeight,
  calculateBatchCost,
  checkStockAvailability,
  calculateFinancialSummary,
} from '../../../../packages/shared/src/calculations/soapMath';
import { getIngredientsDB } from './inventory.controller';

/**
 * Base de datos en memoria para recetas (temporal)
 * En producción, esto se reemplazará con una base de datos real
 */
const recipesDB: Recipe[] = [
  {
    id: '1',
    name: 'Receta Clásica de Castilla',
    description: 'Jabón 100% aceite de oliva, suave y tradicional',
    targetWeight: 1000,
    ingredients: [
      { ingredientId: '2', percentage: 100 }, // 100% Aceite de Oliva
    ],
    overfattingPercentage: 5,
    waterDiscountPercentage: 0,
  },
  {
    id: '2',
    name: 'Receta Balanceada Universal',
    description: 'Mezcla equilibrada para jabón de uso diario',
    targetWeight: 1000,
    ingredients: [
      { ingredientId: '1', percentage: 30 }, // 30% Aceite de Coco
      { ingredientId: '2', percentage: 40 }, // 40% Aceite de Oliva
      { ingredientId: '3', percentage: 20 }, // 20% Aceite de Palma
      { ingredientId: '4', percentage: 10 }, // 10% Manteca de Karité
    ],
    overfattingPercentage: 7,
    waterDiscountPercentage: 10,
  },
  {
    id: '3',
    name: 'Receta Premium Hidratante',
    description: 'Alto contenido de manteca para piel sensible',
    targetWeight: 1000,
    ingredients: [
      { ingredientId: '1', percentage: 25 }, // 25% Aceite de Coco
      { ingredientId: '2', percentage: 35 }, // 35% Aceite de Oliva
      { ingredientId: '4', percentage: 40 }, // 40% Manteca de Karité
    ],
    overfattingPercentage: 8,
    waterDiscountPercentage: 15,
  },
];

/**
 * POST /api/calculator/calculate
 * Procesa el cálculo completo de una receta de jabón
 */
export const processSoapCalculation = (req: Request, res: Response): void => {
  try {
    const { recipeId, targetWeight }: CalculationRequest = req.body;

    // Validaciones de entrada
    if (!recipeId) {
      res.status(400).json({
        success: false,
        error: 'El ID de la receta es obligatorio',
      } as CalculationResponse);
      return;
    }

    if (!targetWeight || targetWeight <= 0) {
      res.status(400).json({
        success: false,
        error: 'El peso objetivo debe ser mayor a 0',
      } as CalculationResponse);
      return;
    }

    // Buscar la receta en la base de datos
    const recipe = recipesDB.find(r => r.id === recipeId);

    if (!recipe) {
      res.status(404).json({
        success: false,
        error: `Receta con ID ${recipeId} no encontrada`,
      } as CalculationResponse);
      return;
    }

    // Obtener datos actuales del inventario
    const ingredientsData = getIngredientsDB();

    // 1. Calcular gramos necesarios de cada ingrediente
    const {
      oils: oilsGrams,
      lyeGrams,
      waterGrams,
      totalOilsWeight,
    } = calculateGramsFromWeight(targetWeight, recipe, ingredientsData);

    // 2. Verificar disponibilidad de stock y generar desglose
    const oilsBreakdown = checkStockAvailability(oilsGrams, ingredientsData);

    // 3. Calcular costos del batch
    const { totalCost, breakdown: costBreakdown } = calculateBatchCost(
      oilsGrams,
      ingredientsData
    );

    // Agregar costo de sosa y agua (estimado)
    const lyeCostPerGram = 0.01; // $0.01 por gramo (ajustar según mercado)
    const waterCostPerGram = 0.001; // $0.001 por gramo (muy bajo)
    const lyeCost = lyeGrams * lyeCostPerGram;
    const waterCost = waterGrams * waterCostPerGram;
    const totalCostWithAllIngredients = totalCost + lyeCost + waterCost;

    // 4. Verificar si se puede hacer el batch
    const canMakeBatch = oilsBreakdown.every(oil => oil.hasEnoughStock);

    // 5. Generar alertas amigables de ingredientes faltantes
    const alerts: string[] = [];

    if (!canMakeBatch) {
      alerts.push('⚠️ No hay suficiente stock para completar este batch:');

      oilsBreakdown
        .filter(oil => !oil.hasEnoughStock)
        .forEach(oil => {
          alerts.push(
            `   • Te faltan ${oil.gramsMissing}g de ${oil.name} (disponible: ${oil.gramsAvailable}g, necesario: ${oil.gramsNeeded}g)`
          );
        });
    } else {
      alerts.push('✅ Tienes suficiente stock para crear este batch');
    }

    // Validar que el batch tenga sentido
    if (targetWeight < 100) {
      alerts.push('ℹ️ El peso objetivo es muy bajo. Se recomienda un mínimo de 100g para un batch práctico.');
    }

    if (targetWeight > 50000) {
      alerts.push('⚠️ El peso objetivo es muy alto. Verifica que sea correcto.');
    }

    // 6. Construir la respuesta completa
    const calculation: SoapCalculation = {
      recipe,
      targetWeight,
      oils: oilsBreakdown,
      lyeGrams: Math.round(lyeGrams * 100) / 100,
      waterGrams: Math.round(waterGrams * 100) / 100,
      totalCost: Math.round(totalCostWithAllIngredients * 100) / 100,
      canMakeBatch,
      alerts,
    };

    res.status(200).json({
      success: true,
      calculation,
    } as CalculationResponse);

  } catch (error) {
    console.error('Error en processSoapCalculation:', error);

    res.status(500).json({
      success: false,
      error: 'Error al procesar el cálculo',
      details: error instanceof Error ? error.message : 'Error desconocido',
    } as CalculationResponse);
  }
};

/**
 * GET /api/calculator/recipes
 * Obtiene todas las recetas disponibles
 */
export const getAllRecipes = (req: Request, res: Response): void => {
  try {
    res.status(200).json({
      success: true,
      data: recipesDB,
      count: recipesDB.length,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Error al obtener las recetas',
      details: error instanceof Error ? error.message : 'Error desconocido',
    });
  }
};

/**
 * GET /api/calculator/recipes/:id
 * Obtiene una receta específica por ID
 */
export const getRecipeById = (req: Request, res: Response): void => {
  try {
    const { id } = req.params;
    const recipe = recipesDB.find(r => r.id === id);

    if (!recipe) {
      res.status(404).json({
        success: false,
        error: `Receta con ID ${id} no encontrada`,
      });
      return;
    }

    res.status(200).json({
      success: true,
      data: recipe,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Error al obtener la receta',
      details: error instanceof Error ? error.message : 'Error desconocido',
    });
  }
};

/**
 * POST /api/calculator/financial-summary
 * Calcula el resumen financiero de un batch
 */
export const getFinancialSummary = (req: Request, res: Response): void => {
  try {
    const { totalCost, soapsPerBatch, desiredProfitMargin } = req.body;

    if (!totalCost || totalCost <= 0) {
      res.status(400).json({
        success: false,
        error: 'El costo total debe ser mayor a 0',
      });
      return;
    }

    if (!soapsPerBatch || soapsPerBatch <= 0) {
      res.status(400).json({
        success: false,
        error: 'La cantidad de jabones por batch debe ser mayor a 0',
      });
      return;
    }

    const profitMargin = desiredProfitMargin || 40; // Default 40% margen

    const summary = calculateFinancialSummary(totalCost, soapsPerBatch, profitMargin);

    res.status(200).json({
      success: true,
      data: summary,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Error al calcular el resumen financiero',
      details: error instanceof Error ? error.message : 'Error desconocido',
    });
  }
};

/**
 * POST /api/calculator/validate-recipe
 * Valida que una receta tenga porcentajes correctos
 */
export const validateRecipe = (req: Request, res: Response): void => {
  try {
    const recipe: Recipe = req.body;
    const errors: string[] = [];

    // Validar que los porcentajes sumen 100%
    const totalPercentage = recipe.ingredients.reduce(
      (sum, ing) => sum + ing.percentage,
      0
    );

    if (Math.abs(totalPercentage - 100) > 0.01) {
      errors.push(
        `Los porcentajes deben sumar 100%. Suma actual: ${totalPercentage.toFixed(2)}%`
      );
    }

    // Validar que todos los ingredientes existan en el inventario
    const ingredientsData = getIngredientsDB();
    const ingredientIds = new Set(ingredientsData.map(ing => ing.id));

    recipe.ingredients.forEach(recipeIng => {
      if (!ingredientIds.has(recipeIng.ingredientId)) {
        errors.push(
          `El ingrediente con ID ${recipeIng.ingredientId} no existe en el inventario`
        );
      }
    });

    // Validar rangos razonables
    if (recipe.overfattingPercentage < 0 || recipe.overfattingPercentage > 20) {
      errors.push('El porcentaje de sobreengrasado debe estar entre 0% y 20%');
    }

    if (recipe.waterDiscountPercentage < 0 || recipe.waterDiscountPercentage > 50) {
      errors.push('El descuento de agua debe estar entre 0% y 50%');
    }

    if (errors.length > 0) {
      res.status(400).json({
        success: false,
        valid: false,
        errors,
      });
      return;
    }

    res.status(200).json({
      success: true,
      valid: true,
      message: 'La receta es válida',
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Error al validar la receta',
      details: error instanceof Error ? error.message : 'Error desconocido',
    });
  }
};
