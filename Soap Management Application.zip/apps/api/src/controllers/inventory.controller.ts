/**
 * @fileoverview Controlador para gestión del inventario de ingredientes
 * @module controllers/inventory
 */

import { Request, Response } from 'express';
import type { Ingredient } from '../../../../packages/shared/src/types';

/**
 * Base de datos en memoria para ingredientes (temporal)
 * En producción, esto se reemplazará con una base de datos real
 */
let ingredientsDB: Ingredient[] = [
  {
    id: '1',
    name: 'Aceite de Coco',
    currentStock: 5000,
    totalCost: 2500,
    costPerGram: 0.5,
    sapValue: 257, // mg KOH por gramo de aceite
  },
  {
    id: '2',
    name: 'Aceite de Oliva',
    currentStock: 10000,
    totalCost: 4000,
    costPerGram: 0.4,
    sapValue: 190,
  },
  {
    id: '3',
    name: 'Aceite de Palma',
    currentStock: 3000,
    totalCost: 1200,
    costPerGram: 0.4,
    sapValue: 199,
  },
  {
    id: '4',
    name: 'Manteca de Karité',
    currentStock: 2000,
    totalCost: 3000,
    costPerGram: 1.5,
    sapValue: 180,
  },
];

/**
 * Calcula el costo por gramo basándose en el costo total y stock actual
 */
function calculateCostPerGram(totalCost: number, currentStock: number): number {
  if (currentStock === 0) {
    return 0;
  }
  return Math.round((totalCost / currentStock) * 1000) / 1000; // 3 decimales
}

/**
 * Valida los datos de un ingrediente
 */
function validateIngredient(ingredient: Partial<Ingredient>): string[] {
  const errors: string[] = [];

  if (!ingredient.name || ingredient.name.trim().length === 0) {
    errors.push('El nombre del ingrediente es obligatorio');
  }

  if (ingredient.currentStock !== undefined && ingredient.currentStock < 0) {
    errors.push('El stock no puede ser negativo');
  }

  if (ingredient.totalCost !== undefined && ingredient.totalCost < 0) {
    errors.push('El costo total no puede ser negativo');
  }

  if (ingredient.sapValue !== undefined && ingredient.sapValue <= 0) {
    errors.push('El valor SAP debe ser mayor a 0');
  }

  return errors;
}

/**
 * GET /api/inventory
 * Obtiene todos los ingredientes del inventario
 */
export const getAllIngredients = (req: Request, res: Response): void => {
  try {
    res.status(200).json({
      success: true,
      data: ingredientsDB,
      count: ingredientsDB.length,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Error al obtener el inventario',
      details: error instanceof Error ? error.message : 'Error desconocido',
    });
  }
};

/**
 * GET /api/inventory/:id
 * Obtiene un ingrediente específico por su ID
 */
export const getIngredientById = (req: Request, res: Response): void => {
  try {
    const { id } = req.params;
    const ingredient = ingredientsDB.find(ing => ing.id === id);

    if (!ingredient) {
      res.status(404).json({
        success: false,
        error: `Ingrediente con ID ${id} no encontrado`,
      });
      return;
    }

    res.status(200).json({
      success: true,
      data: ingredient,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Error al obtener el ingrediente',
      details: error instanceof Error ? error.message : 'Error desconocido',
    });
  }
};

/**
 * POST /api/inventory
 * Crea un nuevo ingrediente en el inventario
 */
export const createIngredient = (req: Request, res: Response): void => {
  try {
    const { name, currentStock, totalCost, sapValue } = req.body;

    // Validar datos de entrada
    const errors = validateIngredient({ name, currentStock, totalCost, sapValue });

    if (errors.length > 0) {
      res.status(400).json({
        success: false,
        error: 'Datos de ingrediente inválidos',
        details: errors,
      });
      return;
    }

    // Calcular automáticamente el costo por gramo
    const costPerGram = calculateCostPerGram(totalCost, currentStock);

    // Generar ID único (en producción usar UUID o ID de base de datos)
    const newId = (Math.max(...ingredientsDB.map(i => parseInt(i.id)), 0) + 1).toString();

    const newIngredient: Ingredient = {
      id: newId,
      name: name.trim(),
      currentStock,
      totalCost,
      costPerGram,
      sapValue,
    };

    ingredientsDB.push(newIngredient);

    res.status(201).json({
      success: true,
      message: 'Ingrediente creado exitosamente',
      data: newIngredient,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Error al crear el ingrediente',
      details: error instanceof Error ? error.message : 'Error desconocido',
    });
  }
};

/**
 * PUT /api/inventory/:id
 * Actualiza un ingrediente existente
 */
export const updateIngredient = (req: Request, res: Response): void => {
  try {
    const { id } = req.params;
    const { name, currentStock, totalCost, sapValue } = req.body;

    const ingredientIndex = ingredientsDB.findIndex(ing => ing.id === id);

    if (ingredientIndex === -1) {
      res.status(404).json({
        success: false,
        error: `Ingrediente con ID ${id} no encontrado`,
      });
      return;
    }

    // Validar datos de entrada
    const errors = validateIngredient({ name, currentStock, totalCost, sapValue });

    if (errors.length > 0) {
      res.status(400).json({
        success: false,
        error: 'Datos de ingrediente inválidos',
        details: errors,
      });
      return;
    }

    const currentIngredient = ingredientsDB[ingredientIndex];

    // Actualizar solo los campos proporcionados
    const updatedIngredient: Ingredient = {
      ...currentIngredient,
      name: name !== undefined ? name.trim() : currentIngredient.name,
      currentStock: currentStock !== undefined ? currentStock : currentIngredient.currentStock,
      totalCost: totalCost !== undefined ? totalCost : currentIngredient.totalCost,
      sapValue: sapValue !== undefined ? sapValue : currentIngredient.sapValue,
    };

    // Recalcular el costo por gramo automáticamente
    updatedIngredient.costPerGram = calculateCostPerGram(
      updatedIngredient.totalCost,
      updatedIngredient.currentStock
    );

    ingredientsDB[ingredientIndex] = updatedIngredient;

    res.status(200).json({
      success: true,
      message: 'Ingrediente actualizado exitosamente',
      data: updatedIngredient,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Error al actualizar el ingrediente',
      details: error instanceof Error ? error.message : 'Error desconocido',
    });
  }
};

/**
 * DELETE /api/inventory/:id
 * Elimina un ingrediente del inventario
 */
export const deleteIngredient = (req: Request, res: Response): void => {
  try {
    const { id } = req.params;
    const ingredientIndex = ingredientsDB.findIndex(ing => ing.id === id);

    if (ingredientIndex === -1) {
      res.status(404).json({
        success: false,
        error: `Ingrediente con ID ${id} no encontrado`,
      });
      return;
    }

    const deletedIngredient = ingredientsDB[ingredientIndex];
    ingredientsDB = ingredientsDB.filter(ing => ing.id !== id);

    res.status(200).json({
      success: true,
      message: 'Ingrediente eliminado exitosamente',
      data: deletedIngredient,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Error al eliminar el ingrediente',
      details: error instanceof Error ? error.message : 'Error desconocido',
    });
  }
};

/**
 * PATCH /api/inventory/:id/adjust-stock
 * Ajusta el stock de un ingrediente (suma o resta)
 */
export const adjustStock = (req: Request, res: Response): void => {
  try {
    const { id } = req.params;
    const { adjustment, reason } = req.body;

    if (adjustment === undefined || typeof adjustment !== 'number') {
      res.status(400).json({
        success: false,
        error: 'Se requiere un valor numérico de ajuste',
      });
      return;
    }

    const ingredientIndex = ingredientsDB.findIndex(ing => ing.id === id);

    if (ingredientIndex === -1) {
      res.status(404).json({
        success: false,
        error: `Ingrediente con ID ${id} no encontrado`,
      });
      return;
    }

    const ingredient = ingredientsDB[ingredientIndex];
    const newStock = ingredient.currentStock + adjustment;

    if (newStock < 0) {
      res.status(400).json({
        success: false,
        error: 'El ajuste resultaría en stock negativo',
        currentStock: ingredient.currentStock,
        attemptedAdjustment: adjustment,
      });
      return;
    }

    ingredient.currentStock = Math.round(newStock * 100) / 100;
    ingredient.costPerGram = calculateCostPerGram(ingredient.totalCost, ingredient.currentStock);

    res.status(200).json({
      success: true,
      message: `Stock ajustado exitosamente${reason ? `: ${reason}` : ''}`,
      data: ingredient,
      adjustment: Math.round(adjustment * 100) / 100,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Error al ajustar el stock',
      details: error instanceof Error ? error.message : 'Error desconocido',
    });
  }
};

/**
 * Exporta la base de datos en memoria (útil para otros controladores)
 */
export const getIngredientsDB = (): Ingredient[] => ingredientsDB;
